$(document).ready(function(){
$('.carousel').carousel();
});
$('.carousel.carousel-slider').carousel({
    fullWidth: true,
    indicators: true
  });